<h2> SIGN UP</h2>
<form method="post" action="signup.php">

	Nama    : <input type="text" name="name"/><br/><br>
		Username: <input type="text" name="username"/><br/><br>
		Password: <input type="password" name="password"/><br/><br>
		Email	: <input type="email" name="email"/><br/><br>
		Nomor Telepon : <input type="text" name="phone_number"/><br/><br>
		<!-- Jenis Kelamin  : <input type="radio" name="jk_input" class="radioB" id="radioB" value="Laki-Laki"/>Laki-Laki<br/>
						 <input type="radio" name="jk_input" class="radioB" id="radioB" value="Perempuan"/>Perempuan<br/> -->
		<input type="submit" value="SUBMIT">
	</table>
</form>