<?php 
	$koneksi = mysqli_connect("localhost","root","","instagram") 
	or die ("Koneksi gagal!");
 ?>